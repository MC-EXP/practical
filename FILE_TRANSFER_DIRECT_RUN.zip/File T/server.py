import socket
import os

# Create TCP/IP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind to IP and Port
server_socket.bind(('0.0.0.0', 5001))
server_socket.listen(1)
print("✅ Server is listening on port 5001...")

# Accept a client connection
client_socket, client_address = server_socket.accept()
print(f"✅ Connection from {client_address} established.")

# Step 1: Receive the filename
filename = client_socket.recv(1024).decode()
print(f"📥 Receiving file: {filename}")

# Step 2: Tell client "OK" to start sending data
client_socket.send(b'OK')

# Step 3: Receive file content
save_path = os.path.join(os.getcwd(), f"received_{filename}")
with open(save_path, 'wb') as file:
    while True:
        data = client_socket.recv(1024)
        if not data:
            break
        file.write(data)

print(f"✅ File received successfully and saved as: {save_path}")

# Close connections
client_socket.close()
server_socket.close()
