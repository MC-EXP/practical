import socket
import os

# Fixed path of your file
file_path = r"C:\Users\Admin\Desktop\File T\example.txt"

# Check if file exists
if not os.path.exists(file_path):
    print("❌ File does not exist! Check the path.")
    exit()

# Create TCP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to server
server_ip = '127.0.0.1'  # Localhost
server_port = 5001
client_socket.connect((server_ip, server_port))
print("✅ Connected to server.")

# Step 1: Send filename
filename = os.path.basename(file_path)
client_socket.send(filename.encode())

# Step 2: Wait for server to send "OK"
server_response = client_socket.recv(1024).decode()
if server_response == 'OK':
    # Step 3: Send file content
    with open(file_path, 'rb') as file:
        data = file.read(1024)
        while data:
            client_socket.send(data)
            data = file.read(1024)

    print("✅ File sent successfully!")
else:
    print("❌ Server did not respond properly.")

# Close connection
client_socket.close()
